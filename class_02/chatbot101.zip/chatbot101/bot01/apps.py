from __future__ import unicode_literals

from django.apps import AppConfig


class Bot01Config(AppConfig):
    name = 'bot01'
